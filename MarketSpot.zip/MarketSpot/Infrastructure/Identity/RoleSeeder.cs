﻿using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;

public static class RoleSeeder
{
    public static async Task SeedRoles(RoleManager<IdentityRole> roleManager)
    {
        if (!await roleManager.RoleExistsAsync("User"))
            await roleManager.CreateAsync(new IdentityRole("User"));

        if (!await roleManager.RoleExistsAsync("Author"))
            await roleManager.CreateAsync(new IdentityRole("Author"));
    }
}
