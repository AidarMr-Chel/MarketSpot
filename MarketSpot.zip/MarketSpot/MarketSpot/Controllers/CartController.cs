﻿using Microsoft.AspNetCore.Mvc;

namespace Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        [HttpPost("checkout")]
        public IActionResult Checkout([FromBody] PaymentRequest request)
        {
            // Логика обработки запроса (проверки, сохранение, интеграция с платежкой)

            return Ok(new { message = "Оплата принята" });
        }
    }

}
