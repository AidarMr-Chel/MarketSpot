﻿using Microsoft.AspNetCore.Mvc;

namespace MarketSpot.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Signup()
        {
            return View();
        }
        public IActionResult AuthorSignup()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Downloads()
        {
            return View();
        }
        public IActionResult MyItems()
        {
            return View();
        }
        public IActionResult Settings()
        {
            return View();
        }
        public IActionResult AddItem()
        {
            return View();
        }

    }
}
