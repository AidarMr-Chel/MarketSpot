﻿using MarketSpot.Application.DTOs;
using MarketSpot.Application.Interfaces;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;


namespace MarketSpot.Controllers
{
    public class MarketController : Controller
    {
        private readonly IProductService _productService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public MarketController(IProductService productService, IHttpContextAccessor httpContextAccessor)
        {
            _productService = productService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("/product/{id}")]
        public async Task<IActionResult> Product(Guid id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
                return NotFound();

            return View(product);
        }

        [Authorize(Roles = "Author")]
        [HttpPost("/product/add")]
        [RequestSizeLimit(50_000_000)]
        [ProducesResponseType(200)]
        public async Task<IActionResult> AddProduct([FromForm] AddProductModel model)
        {
            Console.WriteLine("start controller");
            var userId = User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
                return Unauthorized("User ID not found.");

            Console.WriteLine($"Adding product by user: {userId}");
            Console.WriteLine($"Product Title: {model.Title}");

            try
            {
                await _productService.AddProductAsync(model, userId);
                Console.WriteLine("Product added successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error adding product: " + ex.Message);
                return BadRequest("Error adding product.");
            }

            return Ok("Product uploaded successfully");
        }



        [HttpGet]
        public async Task<IActionResult> SearchJson(string? title, string? category, decimal? minPrice, decimal? maxPrice, int page = 1, int pageSize = 10)
        {
            var result = await _productService.SearchProductsAsync(title, category, minPrice, maxPrice, page, pageSize)
                ?? new PaginatedList<ProductDto>
                {
                    Items = new List<ProductDto>(),
                    TotalCount = 0,
                    Page = 1,
                    PageSize = pageSize
                };

            return Json(result);
        }


        [HttpGet]
        public IActionResult Cart(Guid productId)
        {
            // Можно сохранить productId во ViewBag или TempData
            ViewBag.ProductId = productId;

            return View();
        }

        public IActionResult Pricing()
        {
            return View();
        }
        public IActionResult Product()
        {
            return View();
        }
        public IActionResult Search()
        {
            return View();
        }
    }
}
