﻿using MarketSpot.Application.Interfaces;
using MarketSpot.Core.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MarketSpot.Web.Controllers
{
    [Authorize(Roles = "Author")]
    [Route("Product")]
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly UserManager<ApplicationUser> _userManager;

        public ProductController(IProductService productService, UserManager<ApplicationUser> userManager)
        {
            _productService = productService;
            _userManager = userManager;
        }

        [HttpGet("MyItems")]
        public async Task<IActionResult> MyItems()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
                return RedirectToAction("Login", "Account");

            var products = await _productService.GetProductsByAuthorAsync(user.Id);
            return View("~/Views/Account/MyItems.cshtml", products);
        }

        [Authorize]
        [HttpGet("Delete/{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _productService.DeleteAsync(id);
            return RedirectToAction("MyItems");
        }

    }
}
