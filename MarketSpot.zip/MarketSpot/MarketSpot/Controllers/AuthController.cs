﻿using MarketSpot.Application.DTOs;
using MarketSpot.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MarketSpot.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            var result = await _authService.RegisterAsync(request);
            if (result.Succeeded)
            {
                await _authService.SignInAsync(request.Email, request.Password);
                return Ok(new { message = "User registered and logged in successfully" });
            }
            return BadRequest(result.Errors);
        }

        [HttpPost("register-author")]
        public async Task<IActionResult> RegisterAuthor([FromBody] AuthorRegisterRequest request)
        {
            var result = await _authService.RegisterAuthorAsync(request);
            if (result.Succeeded)
            {
                await _authService.SignInAsync(request.Email, request.Password);
                return Ok(new { message = "Author registered and logged in successfully" });
            }
            return BadRequest(result.Errors);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            await _authService.SignOutAsync(); // на всякий случай
            await _authService.SignInAsync(request.Email, request.Password);

            // Проверим успешный вход
            if (User.Identity.IsAuthenticated)
                return Ok(new { message = "Login successful" });
            else
                return Unauthorized(new { message = "Invalid login attempt" });
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            await _authService.SignOutAsync();
            return Ok(new { message = "Logged out successfully" });
        }
    }
}



//using MarketSpot.Application.DTOs;
//using MarketSpot.Application.Interfaces;
//using Microsoft.AspNetCore.Mvc;
//using System.Threading.Tasks;


//namespace MarketSpot.Web.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class AuthController : ControllerBase
//    {
//        private readonly IAuthService _authService;

//        public AuthController(IAuthService authService)
//        {
//            _authService = authService;
//        }

//        [HttpPost("register")] 
//        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
//        {
//            var result = await _authService.RegisterAsync(request);
//            return result.Succeeded ? Ok(new { message = "User registered successfully" }) : BadRequest(result.Errors);
//        }

//        [HttpPost("register-author")]
//        public async Task<IActionResult> RegisterAuthor([FromBody] AuthorRegisterRequest request)
//        {
//            var result = await _authService.RegisterAuthorAsync(request);
//            return result.Succeeded ? Ok() : BadRequest(result.Errors);
//        }

//        [HttpPost("login")]
//        public async Task<IActionResult> Login([FromBody] LoginRequest request)
//        {
//            var token = await _authService.LoginAsync(request);
//            return token == null ? Unauthorized() : Ok(new { token });
//        }

//    }
//}