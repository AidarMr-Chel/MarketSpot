using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Account
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
