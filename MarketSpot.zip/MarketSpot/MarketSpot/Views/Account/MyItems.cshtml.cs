using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Account
{
    public class MyItemsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
