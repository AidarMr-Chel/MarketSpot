using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Account
{
    public class AuthorSignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
