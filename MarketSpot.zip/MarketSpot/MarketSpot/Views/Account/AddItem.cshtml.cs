using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Account
{
    public class AddItemModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
