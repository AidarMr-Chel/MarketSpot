using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Account
{
    public class DownloadsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
