using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Shared
{
    public class _DashModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
