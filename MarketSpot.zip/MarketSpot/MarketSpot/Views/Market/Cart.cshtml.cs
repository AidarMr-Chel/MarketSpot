using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Market
{
    public class CartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
