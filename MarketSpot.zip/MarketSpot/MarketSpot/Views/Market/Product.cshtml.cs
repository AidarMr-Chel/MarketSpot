using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Market
{
    public class ProductModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
