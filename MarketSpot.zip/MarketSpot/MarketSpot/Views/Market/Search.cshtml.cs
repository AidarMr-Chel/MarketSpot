using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MarketSpot.Views.Market
{
    public class SearchModel : PageModel
    {
        //[BindProperty(SupportsGet = true)]
        //public string? Title { get; set; }

        //[BindProperty(SupportsGet = true)]
        //public string? Category { get; set; }

        //[BindProperty(SupportsGet = true)]
        //public decimal? MinPrice { get; set; }

        //[BindProperty(SupportsGet = true)]
        //public decimal? MaxPrice { get; set; }

        public void OnGet()
        {}
    }

}

