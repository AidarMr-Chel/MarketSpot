﻿namespace MarketSpot.Core.Enums
{
    public static class UserRoles
    {
        public const string User = "User";
        public const string Author = "Author";
    }
}